function ViewCaseForm(){
    return(
        <h3>View Case Information</h3>
    );
}
export default ViewCaseForm;