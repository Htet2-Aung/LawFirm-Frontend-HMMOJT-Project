import lawfirm from "./law_house.jpg"
function Banner(){
        return (
            <div>
                 <section>

              <img src={lawfirm}></img>
        
        </section>
            </div>
        );
}
export default Banner;