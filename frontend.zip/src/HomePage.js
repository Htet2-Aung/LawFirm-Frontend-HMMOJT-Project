function HomePage(){
    return(
        <div>
            <h1>
                This is Home Page.
            </h1>
        </div>
    );
}
export default HomePage;