import { Link } from "react-router-dom";
import ContractList from "../contract/ContractList";
import InqueryList from "../inquery/InqueryList";

function ConTable() {
  
    return (


        <div className="container-fluid">
            <div className="card shadow mb-4">
                <div className="card-header py-3">
                    <h6 className="m-0 font-weight-bold text-primary">DataTables Example</h6>
                    <Link to="/appointment">Back</Link>

                </div>
                <div className="card-body">
                    <div className="container">
                        <table className="table display table-bordered" id="example" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Description</th>
                                    <th>Date</th>
                                    <th>Case</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {/* <ContractList /> */}
                                <tr>
                                <td>ss</td>
                                <td>ss</td>
                                <td>ss</td>
                                <td>ss</td>
                                <td>ss</td>
                                </tr>
                                <tr>
                                <td>aa</td>
                                <td>aa</td>
                                <td>aa</td>
                                <td>aa</td>
                                <td>aa</td>
                                </tr>
                            </tbody>
                            <tfoot>
                            <tr>
                                    <th>Id</th>
                                    <th>Description</th>
                                    <th>Date</th>
                                    <th>Case</th>
                                    <th>Actions</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

       </div> 



    );

}
export default ConTable;