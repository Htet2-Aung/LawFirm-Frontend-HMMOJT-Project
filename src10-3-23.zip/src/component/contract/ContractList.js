import { useSelector} from "react-redux";
import { fetchContracts, getContractStatus, selectAllContract,selectContractsByCaseStatus,selectContractsByDes } from "./contractSlice";
import ContractItem from "./ContractItem";
import { useDispatch } from "react-redux";
import { useEffect } from "react";

function ContractList(props) {
    const initialContracts = useSelector(selectAllContract);
    

    
    //const contract = useSelector((state)=>selectProjectByIdentifier(state,String(contractId))) 
    const searchValue = props.searchValue;
    console.log("in conract list searchValue is "+ searchValue)
    var searchStatus;
    if(searchValue.toLocaleLowerCase()==="yes")
    {
       searchStatus=true;
    }
    else if(searchValue.toLocaleLowerCase()==="no"){
        searchStatus=false;
    }else{
        searchStatus="";
    }
   const contracts = useSelector((state)=>selectContractsByCaseStatus(state,searchStatus))  
    const dispatch = useDispatch();    
    //const contractStatus = useSelector(getContractStatus);
    
    console.log(contracts)
    
    useEffect(()=>{
        
            dispatch(fetchContracts())
            
        
    },[dispatch]);


    
    
    
    
    /*const dispatch = useDispatch();    
    const contractStatus = useSelector(getContractStatus);
    
    console.log(contracts)
    
    useEffect(()=>{
        
            dispatch(fetchContracts())
            
        
    },[dispatch]);*/

    
    //dispatch(fetchContracts)
    

    let content;
    
        content = contracts.map(
            (contract) => (
                <ContractItem
                    id={contract.id}
                    conDescription={contract.conDescription}
                    contractDate={contract.contractDate} 
                    caseStatus={contract.caseStatus} 
    
                />)
    
        );  
    
    return content;

}

export default ContractList;