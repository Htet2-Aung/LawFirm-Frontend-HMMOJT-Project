function AppointmentInfo(){

}
export default AppointmentInfo;