function InstallmentItem(){

}
export default InstallmentItem;