
import ContractList from "./ContractList";
import CreateContractButton from "./CreateContractButton"
//import SearchBar from "../utility/SearchBar";
import { useDispatch } from "react-redux";
import { getContractStatus,fetchContracts,selectAllContract,selectContractsByDes, selectContractsByCaseStatus } from "./contractSlice";
import { useEffect } from "react";
import { useState } from "react";
import { useSelector } from "react-redux";
import SelectComponent from "../SelectComponent";

//define search bar at the top

    //const contract = useSelector((state)=>selectProjectByIdentifier(state,String(contractId))) 
    
    //const dispatch = useDispatch();    
    //const contractStatus = useSelector(getContractStatus);
    
    //console.log(initialContracts)
    
   // useEffect(()=>{
        
            //dispatch(fetchContracts())
            
        
    //},[dispatch]);

    
    //dispatch(fetchContracts)
    //fetch contract to browsers
    /*const fetchCons = (searchValue) => {
        return new Promise((resolve) => {
          setTimeout(() => {
            if (searchValue === "") {
              resolve(initialContracts);
              return;
            }
            const filteredContracts = initialContracts.filter((contract) =>
              contract.conDescription.toLowerCase().includes(searchValue.toLowerCase())
            );
            resolve(filteredContracts);
          }, 2000);
        });
      };
    
      const filterContracts = (searchValue) => {
        if (searchValue === "") {
          return initialContracts;
        }
        return initialContracts.filter((contract) =>
        contract.conDescription.toLowerCase().includes(searchValue.toLowerCase())
        );
      };*/

function ContractTable() {
  const options = [
    { key: 1, value: "All" },
    { key: 2, value: "Yes" },
    { key: 3, value: "No" },
   
  ];
    
  const initialContracts = useSelector(selectAllContract);
  var contracts;  
  const [searchValue, setSearchValue] = useState("");
  const onClientStatusChange = e => setSearchValue(e.target.value);

   const dispatch = useDispatch();    
    //const contractStatus = useSelector(getContractStatus);
    
    console.log(initialContracts)
    
    useEffect(()=>{
        
            dispatch(fetchContracts())
            
        
    },[dispatch]);

    var searchStatus;
    if(searchValue.toLocaleLowerCase()==="yes")
    {
      searchStatus=true;
    }
    else if(searchValue.toLocaleLowerCase()==="no"){
      searchStatus=false;
    }
    else{
      searchStatus="";
    }
    contracts = useSelector((state)=>selectContractsByCaseStatus(state,searchStatus)) 

    if (searchValue === "")
    {
      contracts=initialContracts
    }
    
      
    

  
        //const [contracts, setContracts] = useState([]);
        
      
       /* useEffect(() => {
          setContracts([]);
          fetchCons(searchValue).then((contracts) => {
              setContracts(contracts);
          });
          // const filteredArticles = filterArticles(searchValue);
          // setArticles(filteredArticles);
        }, [searchValue,setContracts]);*/
  console.log("Search Value in Contract Table"+ searchValue)
      return (
          <div className="container">
            <div className="row">
                <div className="col-9 my-3"><CreateContractButton /></div>
                <div className="col-3 my-3">
                <select
                                            className="form-control "
                                            value={searchValue}
                                            onChange={onClientStatusChange}>
                                        
                                            <option value="">Select Case Status</option>
                                            <option value="yes">Created</option>
                                            <option value="no">Not Created</option>
                  </select>
                </div>
            </div>
            <div className="row">
                    <table id="example" className="table table-striped">
                        <thead className="table-success">
                            <tr className="table-primary text-dark text-center">
                                <th>Contract Id</th>
                                <th>Contract Description</th>
                                <th>Contract Date</th>
                                <th>Case Create</th>
                                <th>Actions</th>

                            </tr>
                        </thead>
                        <tbody>
                            <ContractList searchValue={searchValue}/>
                        </tbody>
                    </table>
              </div>
                    
          </div>
          
      );
    

    




}


export default ContractTable;