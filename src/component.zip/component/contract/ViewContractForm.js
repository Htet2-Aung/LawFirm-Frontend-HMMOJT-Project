import { updateContract, selectContractById } from "./contractSlice"
import { useDispatch } from "react-redux";
import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
//import { getToken } from "../auth/authSlice";
import contractImg from "./img/contractImg.jpg";
import UserInfo from "../user/UserInfo";
import EditCaseForm from "../case/EditCaseForm";
import ViewCaseForm from "../case/ViewCaseForm";
import ViewAppointmentForm from "../appointment/ViewAppointmentForm";
import casesSlice from "../case/casesSlice";
import LawyerInfo from "../user/LawyerInfo";


function ViewContractForm(props) {
    const { contractId } = useParams()
    console.log(contractId)
    console.log(typeof contractId)



    const contract = useSelector((state) => selectContractById(state, Number(contractId)))


    console.log(contract)



    const id = useState(contract.id);
    const contractDate = useState(contract.contractDate);
    const conDescription = useState(contract.conDescription);

    var cases = "No"
    if (contract.caseStatus) {
        cases = "Yes"
    }









    return (




        <div className="container bg-light">

            <div className="row">
                <img src={contractImg} className="my-3" />
            </div>
            <div className="row my-3">

                <div className="row">

                    <div className="row">
                        <center><h3 > Contract Information</h3></center>
                        <div className="row my-3">
                            <div className="col-4"><label>Contract id</label></div>
                            <div className="col-8"><label>{id}</label></div>
                        </div>
                        <div className="row my-3">
                            <div className="col-4"><label>Contract Date</label></div>
                            <div className="col-8"><label>{contractDate}</label></div>
                        </div>
                        <div className="row my-3">
                            <div className="col-4"><label>Case Created</label></div>
                            <div className="col-8"><label>{cases}</label></div>
                        </div>
                        <div className="row my-3">
                            <div className="col-4"><label>Description</label></div>
                            <div className="col-8"><label>{conDescription}</label></div>
                        </div>

                    </div>

                    <div ><ViewAppointmentForm /></div>
                    <div className="my-5"><ViewCaseForm /></div>

                    <div className="row">
                        <div className="col"><UserInfo /></div>
                        <div className="col"><LawyerInfo /></div>

                    </div>
                    
                </div>

            </div>
        </div>





    );
}
export default ViewContractForm;