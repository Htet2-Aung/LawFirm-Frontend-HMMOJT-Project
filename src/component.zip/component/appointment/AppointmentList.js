import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { getToken, getUser } from "../auth/authSlice"
import Appointment from "./Appointment"
import { fetchAppointment, fetchAppointmentAdmin, getAppointmentError, getAppointmentStatus, selectAllIAppointment } from "./appointmentSlice"

function AppointmentList(){
    const dispatch = useDispatch()
    const appointments = useSelector(selectAllIAppointment)
    console.log("InqueryList: "+appointments)
    const appointmentStatus = useSelector(getAppointmentStatus)
    const error=useSelector(getAppointmentError);
    const token = useSelector(getToken)
    const user = useSelector(getUser)

        const appointmentAdmin = useSelector(selectAllIAppointment)

    useEffect(() => {
        console.log("Appointment List Token:"+token)
        if(appointmentStatus === 'idle'){
            if(user.role === 'Admin'){
                console.log("Admin see Appointment List")
                dispatch(fetchAppointmentAdmin())
            }
            else{
                if(token){

                    // dispatch(fetchAppointment({user:user,token}))
                }else{
                    console.log("In appointment, Invalid token!")
                }
            }
        }
        },[appointmentStatus,dispatch,token])

        let content;

        if(appointmentStatus === 'loading'){
            content = (<p>Loading....</p>)
        }
        if(appointmentStatus === 'succeeded'){
            console.log(appointmentStatus)
            content = appointments.map(
                (appointment) => (
                    <Appointment
                       id={appointment.id}
                        name={appointment.name} 
                        consultantFees={appointment.consultantFees} 
                        clientStatus={appointment.clientStatus}
                        lawyerStatus={appointment.lawyerStatus}
                        date={appointment.date}
                        time={appointment.time}
                    />
                )
            );
        }
        if(appointmentStatus === 'failed'){
            content = (<p>{error}</p>);
        }
 

    return content;
}
export default AppointmentList;