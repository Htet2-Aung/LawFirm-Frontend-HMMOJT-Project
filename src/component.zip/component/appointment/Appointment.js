import { useState } from "react";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import ConfirmModal from "../utility/ConfirmModal";
import { deleteAppointment } from "./appointmentSlice";

function Appointment(props) {
    console.log(props.id);

    const [isModalOpen, setModalOpen] = useState(false)
    const dispatch = useDispatch();

    function deleteHandler() {
        setModalOpen(true);
    }

    function cancelHandler() {
        setModalOpen(false);
    }

    function confirmHandler() {
        dispatch(deleteAppointment({ appointmentId: props.id })).unwrap()

        setModalOpen(false)
    }

    return (

        <tr>
            <td>{props.id}</td>
            <td>{props.name}</td>
            <td>{props.consultantFees}</td>
            <td>{props.lawyerStatus}</td>
            <td>{props.clientStatus}</td>
            <td>{props.date}</td>
            <td>{props.time}</td>
            <td>
                <Link to={`/appointment/edit/${props.id}`}>
                <i title="Edit Appointment" className='fas fa-edit text-success mx-3'></i>
                </Link>
                <Link onClick={deleteHandler}>
                <i title="Delete" className="fa fa-minus-circle pr-1 mx-2 text-danger "></i>
                </Link>
                <Link to={`/contract/create/${props.id}`}>
                   <i title="Create Contract" className="fas fa-scroll text-primary"></i>
                </Link>
                </td> 
                {isModalOpen && <ConfirmModal onCancel={cancelHandler} onConfirm={confirmHandler} />}
                {isModalOpen && <ConfirmModal onCancel={cancelHandler} onConfirm={confirmHandler} />}
        </tr>
       
            


    );
}
export default Appointment;