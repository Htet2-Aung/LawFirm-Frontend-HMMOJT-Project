import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { getToken, getUser } from "../auth/authSlice";
import ConfirmModal from "../utility/ConfirmModal";
import { deleteInquery } from "./inquerySlice";

function InqueryItem(props) {
    const token=useSelector(getToken)
    console.log("In the inquery Item and token is "+ token)

    const user = useSelector(getUser)
    console.log("In the inquery Item "+user.role)

    function Admin(){
        return(
            <td className="text-center">
            <Link  to={`info/${props.id}`}>
                <i title="Information" className="bi bi-info-circle text-info"></i>
            </Link>
            <Link onClick={deleteHandler}>
            <i title="Delete" className="fa fa-minus-circle pr-1 mx-2 text-danger "></i>
            </Link>
            <SetLink />
            {/* <Link to={`/appointment/create/${props.id}`}>
                <button className="btn btn-light mx-2"><i className='fas fa-paste text-primary'></i>Appointment</button>
                </Link> */}
            {isModalOpen && <ConfirmModal onCancel={cancelHandler} onConfirm={confirmHandler} />}

           </td>
        );
    }
    function User(){
        return(
            <td className="text-center">
                <Link to={`info/${props.id}`}>
                    <i title="View Inquiry" className="bi bi-info-circle text-info"></i>
                </Link>
            
                <Link to={`/inquery/edit/${props.id}`}>
                <i className='fas fa-edit text-success mx-3'></i>
                </Link>
                <Link onClick={deleteHandler}>
                <i title="Delete" className="fa fa-minus-circle pr-1 mx-2 text-danger "></i>
                </Link>
                {isModalOpen && <ConfirmModal onCancel={cancelHandler} onConfirm={confirmHandler} />}

               </td>
        );
    }
   
    console.log(props.id);

    function LinkItem() {
        return (
            <Link to={`/appointment/create/${props.id}`}>
               <i title="Appointment create" className='fas fa-paste text-primary'></i>
            </Link>
        );
    }
    function UnLinkItem() {
        return (
           <i title="Created Appointment" className='fas fa-paste text-success'></i>
        );
    }

    function SetLink() {
        let content;
        console.log("in the setLink")
        console.log(props.appointmentStatus)
        if (props.appointmentStatus === 'CREATED') {
            content = <UnLinkItem />
        }
        else {
            content = <LinkItem />
        }
        return content;
    }

    console.log(props.id);


    const [isModalOpen, setModalOpen] = useState(false)
    const dispatch = useDispatch();
    const appointmentStatus = props.appointmentStatus
    console.log("Id for AppointmentStatus"+appointmentStatus)
   
 
    function deleteHandler(){
        setModalOpen(true);
    }

    // function backdropHandler(){
    //     setModalOpen(false);
    // }

    function cancelHandler(){
        setModalOpen(false);
    }

    function confirmHandler(){
        dispatch(deleteInquery({inqueryId:props.id,token})).unwrap()

        setModalOpen(false)
    }

          
            let result;
            if(user.role === 'User'){
                result =(
                    <tr id="data_table tr">
                    <td> {props.no}</td>
                    <td>{props.lawyerName}</td>
                    <td>{props.phoneNo}</td>
                    {/* <td>{props.description}</td> */}
                    <td>{props.appointmentStatus}</td>
                    <User/>
                    
            </tr>
                )
            }else if(user.role === 'Admin'){
             
                
                result = (
                    <tr id="data_table tr">
                    <td> {props.no}</td>
                    <td>{props.lawyerName}</td>
                    <td>{props.phoneNo}</td>
                    {/* <td>{props.description}</td> */}
                    <td>{props.appointmentStatus}</td>
                    <Admin />
                    
            </tr>
                
                )
                
            }
            return result;
}
export default InqueryItem;