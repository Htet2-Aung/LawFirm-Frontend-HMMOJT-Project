import lawfirm from "./law_house.jpg"
function Banner(){
        return (
            <div>
            <h1>Login Fail!!!</h1>
                 <section>
              
              <img src={lawfirm}></img>
        
        </section>
            </div>
        );
}
export default Banner;